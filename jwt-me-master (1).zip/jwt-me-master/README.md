# jwt-me
This is a JWT authentication sample, implemented using Spring Boot.

A complete guide can be found on [http://andreybleme.com/2017-04-01/autenticacao-com-jwt-no-spring-boot/](http://andreybleme.com/2017-04-01/autenticacao-com-jwt-no-spring-boot/)


